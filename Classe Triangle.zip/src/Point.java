public class Point {
    int posx, posy;

    public Point() {
    }

    public Point(int abscisse, int ordonne) {
        this.posx = abscisse;
        this.posy = ordonne;
    }

    public int getPosx() {
        return posx;
    }

    public int getPosy() {
        return posy;
    }

    public void setPosx(int posx) {
        this.posx = posx;
    }

    public void setPosy(int posy) {
        this.posy = posy;
    }

    public String toString() {
        return "Point (" + posx +
                ", " + posy +
                ')';
    }

    public double distance(Point p) {
        int distanceX = p.posx - posx;
        int distanceY = p.posy - posy;
        double distancefinale = Math.sqrt((distanceX * distanceX) + (distanceY * distanceY));
        return Math.round(distancefinale);
    }

    public void deplaceToi(int newx, int newy) {
        setPosx(newx);
        setPosy(newy);
    }


    public static void main(String[] args) {
        Point un = new Point(1, 1);
        Point deux = new Point(-2, -2);
        Point trois = new Point(-3, 3);

        System.out.println(un.toString());
        System.out.println(deux.toString());
        System.out.println(trois.toString());
    }
}