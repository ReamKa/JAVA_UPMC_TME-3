public class Triangle {
    Point p1;
    Point p2;
    Point p3;

    public Triangle(){
    }
    public Triangle(Point sommet1, Point sommet2, Point sommet3){
        p1 = sommet1;
        p2 = sommet2;
        p3 = sommet3;
    }
    public double getPerimetre(){
        return p1.distance(p2) + p2.distance(p3) + p3.distance(p1);
    }
    public String toString(){
        return "Le triangle a pour sommet A : " + p1.toString() + ". Pour sommet B : " + p2.toString() + ". Pour sommet C : " + p3.toString();
    }
}
