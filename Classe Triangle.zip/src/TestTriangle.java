public class TestTriangle {
    public static void main(String[] args) {
        //Creation des points
        Point un = new Point(1, 1);
        Point deux = new Point(-2, -2);
        Point trois = new Point(-3, 3);

        //Creation du triangle
        Triangle t1 = new Triangle(un, deux, trois);

        //Ses 3 points, la longueur de ses cotes et son perimetre
        System.out.println(t1.toString());

        System.out.println("La longeur AB vaut : " + un.distance(deux) + " cm.");
        System.out.println("La longueur BC vaut : " + deux.distance(trois) + " cm.");
        System.out.println("La longueur CA vaut : "+ trois.distance(un) + " cm.");

        System.out.println("Le perimetre du triangle vaut : " + t1.getPerimetre() + " cm.");
    }
}
