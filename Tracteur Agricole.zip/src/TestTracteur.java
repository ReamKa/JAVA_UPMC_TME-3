public class TestTracteur {
    public static void main (String[] args) throws CloneNotSupportedException {
        Roue petite = new Roue();
        Roue petita = new Roue();
        Roue grande = new Roue(120);
        Roue granda = new Roue(120);

        System.out.println(petite.toString());

        Cabine bleue = new Cabine(3, "bleue");
        System.out.println(bleue.toString());

        //Creation tracteur
        Tracteur t1 = new Tracteur(bleue, petite, petita, grande, granda);
        System.out.println(t1.toString());

        /* Ici le tracteur t1 devenait bien rose
        Tracteur t2 = t1;
        t2.peindre("rose");
        System.out.println(t1.toString());
        */

        System.out.println("--------------------------------------------------------------");
        //J'ai crée tout pleins de copie de constructeur dans Tracteur pour que t1 et t2 soient 2 objets distincts car ca marchait pas
        Tracteur t2 = new Tracteur(t1);
        Tracteur t3 = Tracteur.copieDe(t1);
        Tracteur t4 = (Tracteur) t1.clone();


        t2.peindre("rose");
        t4.peindre("وردي");

        System.out.println(t1.toString());
        System.out.println(t2.toString());
        System.out.println(t4.toString());

    }
}
