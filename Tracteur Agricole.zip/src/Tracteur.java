public class Tracteur implements Cloneable{
    Cabine cabine;
    Roue une, deux, trois, quatre;

    public Tracteur(Cabine cabine, Roue un, Roue deux, Roue trois, Roue quatre){
        this.cabine = cabine;
        this.une = un;
        this.deux = deux;
        this.trois = trois;
        this.quatre = quatre;
    }
    //Premiere copie
    public Tracteur(Tracteur t){
        cabine = new Cabine(t.cabine.volume, t.cabine.couleur);
        une = new Roue(t.une.diametre);
        deux = new Roue (t.deux.diametre);
        trois = new Roue(t.trois.diametre);
        quatre = new Roue(t.quatre.diametre);
    }
    //Deuxieme copie
    public static Tracteur copieDe(Tracteur t1){
        return new Tracteur(new Cabine (t1.cabine.volume, t1.cabine.couleur),
                new Roue (t1.une.diametre),
                new Roue (t1.deux.diametre),
                new Roue (t1.trois.diametre),
                new Roue(t1.quatre.diametre));
    }
    //Troisieme copie
    public Object clone() throws CloneNotSupportedException{
        return new Tracteur(new Cabine (this.cabine.volume, this.cabine.couleur),
                new Roue (this.une.diametre),
                new Roue (this.deux.diametre),
                new Roue (this.trois.diametre),
                new Roue (this.quatre.diametre));
    }
    public String toString() {
        return "Tracteur avec une cabine de nom : " + cabine +
                ", une " + une +
                ", une " + deux +
                ", une " + trois +
                ", et une derniere  " + quatre;
    }
    public void peindre (String couleur){
        cabine.couleur = couleur;
    }
}
