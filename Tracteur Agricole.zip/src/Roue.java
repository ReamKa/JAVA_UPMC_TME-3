public class Roue {
    protected int diametre;

    public Roue(int diametre){
        this.diametre = diametre;
    }
    public Roue(){
        this(60);
    }
    public String toString() {
        return "Roue de diametre : " + diametre + " cm";
    }
}
